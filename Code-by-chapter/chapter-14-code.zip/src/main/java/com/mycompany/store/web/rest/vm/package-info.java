/**
 * View Models used by Spring MVC REST controllers.
 */
package com.mycompany.store.web.rest.vm;
