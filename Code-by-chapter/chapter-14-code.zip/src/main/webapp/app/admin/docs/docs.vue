<template>
    <iframe src="swagger-ui/index.html" width="100%" height="900" seamless
            target="_top" title="Swagger UI" class="border-0"></iframe>
</template>

<script lang="ts" src="./docs.component.ts">
</script>

