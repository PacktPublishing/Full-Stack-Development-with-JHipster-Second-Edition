import { Store } from 'vuex';

export default class JhiAlertService {
  private store: Store<{}>;

  constructor(store: Store<{}>) {
    this.store = store;
    this.store.commit('initAlert');
  }

  public showAlert(alertMessage: any, alertType = 'info') {
    this.store.commit('setAlertType', alertType);
    this.store.commit('setAlertMessage', alertMessage);
  }

  public countDownChanged(dismissCountDown: number) {
    this.store.commit('countDownChanged', dismissCountDown);
  }
}
