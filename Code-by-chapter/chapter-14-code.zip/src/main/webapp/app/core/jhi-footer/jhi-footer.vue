<template>
    <div id="footer" class="footer">
        <p v-text="$t('footer')">This is your footer</p>
    </div>
</template>

<script lang="ts" src="./jhi-footer.component.ts">
</script>

<style scoped>
    .footer {
        text-align: left;
    }
</style>
