import { ElementFinder, $ } from 'protractor';

import AlertPage from './alert-page';

export default class PasswordPage extends AlertPage {
  selector: ElementFinder = $('#password-form');
  currentPassword: ElementFinder = this.selector.$('#currentPassword');
  newPassword: ElementFinder = this.selector.$('#newPassword');
  confirmPassword: ElementFinder = this.selector.$('#confirmPassword');
  saveButton: ElementFinder = this.selector.$('button[type=submit]');
  title: ElementFinder = $('#password-title');

  async getTitle() {
    return await this.title.getAttribute('id');
  }

  async autoChangePassword(currentPassword: string, newPassword: string, confirmPassword: string) {
    await this.currentPassword.sendKeys(currentPassword);
    await this.newPassword.sendKeys(newPassword);
    await this.confirmPassword.sendKeys(confirmPassword);
    await this.saveButton.click();
  }
}
