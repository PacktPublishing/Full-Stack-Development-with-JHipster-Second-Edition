import { $, ElementFinder } from 'protractor';

import AlertPage from './alert-page';

export default class settingsForm extends AlertPage {
  settingsForm: ElementFinder = $('#settings-form');
  firstName: ElementFinder = this.settingsForm.$('#firstName');
  lastName: ElementFinder = this.settingsForm.$('#lastName');
  email: ElementFinder = this.settingsForm.$('#email');
  saveButton: ElementFinder = this.settingsForm.$('button[type=submit]');
  title: ElementFinder = $('#settings-title');

  async getTitle() {
    return this.title.getAttribute('id');
  }
}
