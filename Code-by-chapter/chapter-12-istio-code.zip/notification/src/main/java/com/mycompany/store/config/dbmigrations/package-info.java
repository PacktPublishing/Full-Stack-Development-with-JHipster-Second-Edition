/**
 * MongoDB database migrations using MongoBee.
 */
package com.mycompany.store.config.dbmigrations;
