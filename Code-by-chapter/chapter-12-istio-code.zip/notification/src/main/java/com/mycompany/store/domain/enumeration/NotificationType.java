package com.mycompany.store.domain.enumeration;

/**
 * The NotificationType enumeration.
 */
public enum NotificationType {
    EMAIL, SMS, PARCEL
}
