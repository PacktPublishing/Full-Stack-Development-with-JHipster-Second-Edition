/**
 * Data Access Objects used by WebSocket services.
 */
package com.mycompany.store.web.websocket.dto;
