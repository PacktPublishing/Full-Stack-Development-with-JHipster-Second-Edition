/**
 * Spring Framework configuration files.
 */
package com.mycompany.store.config;
