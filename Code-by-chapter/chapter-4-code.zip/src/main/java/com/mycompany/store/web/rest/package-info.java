/**
 * Spring MVC REST controllers.
 */
package com.mycompany.store.web.rest;
