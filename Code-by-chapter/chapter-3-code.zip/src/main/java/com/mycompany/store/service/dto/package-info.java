/**
 * Data Transfer Objects.
 */
package com.mycompany.store.service.dto;
