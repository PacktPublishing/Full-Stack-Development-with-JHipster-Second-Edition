/**
 * Spring Data JPA repositories.
 */
package com.mycompany.store.repository;
