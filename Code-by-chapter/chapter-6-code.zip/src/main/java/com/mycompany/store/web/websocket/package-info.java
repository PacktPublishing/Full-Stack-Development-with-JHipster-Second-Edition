/**
 * WebSocket services, using Spring Websocket.
 */
package com.mycompany.store.web.websocket;
