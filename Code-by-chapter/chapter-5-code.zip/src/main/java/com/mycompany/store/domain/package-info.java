/**
 * JPA domain objects.
 */
package com.mycompany.store.domain;
